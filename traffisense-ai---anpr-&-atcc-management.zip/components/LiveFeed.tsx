
import React, { useState, useEffect, useRef } from 'react';
import { Maximize2, Camera, Circle, Volume2, Settings2 } from 'lucide-react';

const LiveFeed: React.FC = () => {
  const [activeCamera, setActiveCamera] = useState('01-MainJunction');
  const videoRef = useRef<HTMLVideoElement>(null);

  // Note: For a real app, we'd use navigator.mediaDevices.getUserMedia(video: true)
  // Here we use a high-quality placeholder to simulate traffic feed

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Main Feed */}
      <div className="lg:col-span-3 space-y-4">
        <div className="relative aspect-video bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
          {/* Simulation Overlay */}
          <div className="absolute inset-0 z-10 pointer-events-none">
            {/* Detection Box 1 */}
            <div className="absolute border-2 border-emerald-500 bg-emerald-500/10 top-1/4 left-1/3 w-32 h-20 animate-pulse">
              <div className="absolute -top-6 left-0 bg-emerald-500 text-white text-[10px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">
                CAR | CONF 0.98
              </div>
            </div>
            {/* Detection Box 2 */}
            <div className="absolute border-2 border-blue-500 bg-blue-500/10 bottom-1/3 right-1/4 w-40 h-28 animate-pulse">
              <div className="absolute -top-6 left-0 bg-blue-500 text-white text-[10px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">
                BUS | CONF 0.94
              </div>
            </div>
            {/* OCR Line */}
            <div className="absolute top-1/2 left-0 w-full h-px bg-rose-500/50 flex items-center justify-center">
              <span className="bg-rose-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-tighter">
                OCR DETECTION ZONE
              </span>
            </div>
          </div>

          <img 
            src="https://images.unsplash.com/photo-1542401886-65d6c60db27b?auto=format&fit=crop&q=80&w=2000" 
            alt="Live Traffic Feed" 
            className="w-full h-full object-cover"
          />

          {/* Controls Overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent flex justify-between items-center z-20">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Circle className="fill-rose-500 text-rose-500 animate-pulse" size={12} />
                <span className="text-white font-bold text-sm uppercase tracking-widest">{activeCamera}</span>
              </div>
              <span className="text-slate-400 text-xs font-medium mono">192.168.1.104 • 4K @ 60FPS</span>
            </div>
            <div className="flex items-center gap-3">
              <button className="bg-slate-800/80 p-2 rounded-lg text-white hover:bg-slate-700 transition-colors">
                <Volume2 size={18} />
              </button>
              <button className="bg-slate-800/80 p-2 rounded-lg text-white hover:bg-slate-700 transition-colors">
                <Maximize2 size={18} />
              </button>
            </div>
          </div>
        </div>

        <div className="flex gap-4 p-4 bg-slate-900 border border-slate-800 rounded-xl">
          <div className="flex-1 flex flex-col gap-1">
            <span className="text-[10px] font-bold text-slate-500 uppercase">Engine Status</span>
            <span className="text-emerald-400 text-sm font-medium">YOLOv8x-Custom Opt.</span>
          </div>
          <div className="w-px bg-slate-800"></div>
          <div className="flex-1 flex flex-col gap-1">
            <span className="text-[10px] font-bold text-slate-500 uppercase">Inference Time</span>
            <span className="text-white text-sm font-medium">12.4ms</span>
          </div>
          <div className="w-px bg-slate-800"></div>
          <div className="flex-1 flex flex-col gap-1">
            <span className="text-[10px] font-bold text-slate-500 uppercase">Active Threads</span>
            <span className="text-white text-sm font-medium">16 Threads</span>
          </div>
        </div>
      </div>

      {/* Camera Selection & Side Panel */}
      <div className="space-y-4">
        <h3 className="text-sm font-bold text-slate-500 uppercase tracking-widest px-2">Active Cameras</h3>
        <div className="space-y-2">
          {['01-MainJunction', '02-SideStreet-East', '03-HighwayExit-12', '04-TollPlaza-North'].map((cam) => (
            <button 
              key={cam}
              onClick={() => setActiveCamera(cam)}
              className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all ${
                activeCamera === cam 
                ? 'bg-blue-600/10 border-blue-500 text-white' 
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center gap-3">
                <Camera size={18} className={activeCamera === cam ? 'text-blue-400' : 'text-slate-500'} />
                <span className="text-sm font-medium">{cam}</span>
              </div>
              {activeCamera === cam && <div className="w-2 h-2 bg-blue-500 rounded-full"></div>}
            </button>
          ))}
        </div>

        <div className="mt-8 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <div className="flex items-center gap-2 mb-4">
            <Settings2 size={18} className="text-slate-400" />
            <h4 className="text-sm font-bold text-white uppercase tracking-tight">Stream Config</h4>
          </div>
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-[10px] font-bold text-slate-500 uppercase">
                <span>Confidence Threshold</span>
                <span>85%</span>
              </div>
              <div className="h-1.5 bg-slate-800 rounded-full">
                <div className="h-full w-[85%] bg-blue-500 rounded-full"></div>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-300 font-medium">Save Violation Clips</span>
              <div className="w-8 h-4 bg-blue-600 rounded-full relative">
                <div className="absolute right-0.5 top-0.5 w-3 h-3 bg-white rounded-full"></div>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-300 font-medium">Auto-Report ANPR</span>
              <div className="w-8 h-4 bg-slate-700 rounded-full relative">
                <div className="absolute left-0.5 top-0.5 w-3 h-3 bg-white rounded-full"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveFeed;
