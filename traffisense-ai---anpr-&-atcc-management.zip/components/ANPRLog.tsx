
import React from 'react';
import { ANPREvent } from '../types';
import { Search, Filter, Download } from 'lucide-react';

interface Props {
  events: ANPREvent[];
}

const ANPRLog: React.FC<Props> = ({ events }) => {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
        <div className="relative flex-1 w-full max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
          <input 
            type="text" 
            placeholder="Search by Plate Number, Lane, or Vehicle Type..." 
            className="w-full bg-slate-900 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/50 text-sm"
          />
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <button className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-slate-900 border border-slate-800 px-4 py-2.5 rounded-xl text-slate-300 hover:text-white transition-colors text-sm">
            <Filter size={18} />
            Filter
          </button>
          <button className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 px-4 py-2.5 rounded-xl text-white transition-colors text-sm font-medium">
            <Download size={18} />
            Export CSV
          </button>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 font-medium">
              <tr>
                <th className="px-6 py-4">Timestamp</th>
                <th className="px-6 py-4">Plate Image</th>
                <th className="px-6 py-4">Plate Number</th>
                <th className="px-6 py-4">Vehicle Type</th>
                <th className="px-6 py-4 text-center">Lane</th>
                <th className="px-6 py-4 text-center">Confidence</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {events.map((event) => (
                <tr key={event.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-slate-300">
                    <div className="flex flex-col">
                      <span className="font-medium">{event.timestamp.toLocaleTimeString()}</span>
                      <span className="text-[10px] text-slate-500">{event.timestamp.toLocaleDateString()}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <img src={event.imageUrl} className="h-10 w-20 object-cover rounded-md border border-slate-700 grayscale hover:grayscale-0 transition-all cursor-zoom-in" />
                  </td>
                  <td className="px-6 py-4">
                    <span className="mono bg-slate-950 px-3 py-1 rounded-md border border-slate-800 text-blue-400 font-bold tracking-widest uppercase">
                      {event.plateNumber}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-slate-300 font-medium">
                    {event.vehicleType}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-slate-950 border border-slate-800 text-xs font-bold text-slate-300">
                      {event.lane}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <div className="flex flex-col gap-1 items-center">
                      <div className="w-16 h-1 bg-slate-800 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-emerald-500 rounded-full" 
                          style={{ width: `${event.confidence * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-[10px] font-medium text-emerald-400">{Math.round(event.confidence * 100)}%</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="text-slate-500 hover:text-white transition-colors p-1">
                      <Search size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ANPRLog;
