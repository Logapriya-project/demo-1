
import React, { useEffect, useState } from 'react';
import { TrafficStats, ANPREvent, TrafficInsight } from '../types.ts';
import { getTrafficInsights } from '../services/geminiService.ts';
import { 
  Car, 
  Zap, 
  Wind, 
  AlertCircle, 
  ChevronRight,
  ShieldCheck,
  BrainCircuit
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

interface Props {
  stats: TrafficStats;
  events: ANPREvent[];
}

const mockChartData = [
  { time: '08:00', flow: 400 },
  { time: '09:00', flow: 600 },
  { time: '10:00', flow: 450 },
  { time: '11:00', flow: 380 },
  { time: '12:00', flow: 420 },
  { time: '13:00', flow: 390 },
  { time: '14:00', flow: 480 },
];

const TrafficDashboard: React.FC<Props> = ({ stats, events }) => {
  const [insights, setInsights] = useState<TrafficInsight | null>(null);
  const [loadingInsights, setLoadingInsights] = useState(true);

  useEffect(() => {
    const fetchInsights = async () => {
      setLoadingInsights(true);
      const data = await getTrafficInsights(stats);
      setInsights(data);
      setLoadingInsights(false);
    };
    fetchInsights();
    const interval = setInterval(fetchInsights, 60000);
    return () => clearInterval(interval);
  }, [stats]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Vehicle Count" 
          value={stats.totalVehicles.toLocaleString()} 
          change="+12% from last hour" 
          icon={<Car className="text-blue-500" />} 
        />
        <StatCard 
          title="Avg Speed" 
          value={`${stats.averageSpeed} km/h`} 
          change="-2 km/h decrease" 
          icon={<Zap className="text-amber-500" />} 
        />
        <StatCard 
          title="Congestion" 
          value={stats.congestionLevel} 
          status={stats.congestionLevel === 'Critical' ? 'error' : stats.congestionLevel === 'Medium' ? 'warning' : 'success'}
          icon={<AlertCircle className="text-red-500" />} 
        />
        <StatCard 
          title="Detection Rate" 
          value="98.4%" 
          change="AI Model optimized" 
          icon={<ShieldCheck className="text-emerald-500" />} 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-semibold text-white">Traffic Volume (ATCC)</h3>
            <span className="px-3 py-1 bg-blue-600/20 text-blue-400 text-xs rounded-full border border-blue-600/30 font-medium">Real-time</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockChartData}>
                <defs>
                  <linearGradient id="colorFlow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="time" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '8px' }}
                  itemStyle={{ color: '#3b82f6' }}
                />
                <Area type="monotone" dataKey="flow" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorFlow)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-indigo-950/30 border border-indigo-500/30 rounded-2xl p-6 relative overflow-hidden">
          <div className="flex items-center gap-2 mb-4">
            <div className="bg-indigo-500 p-1.5 rounded-lg">
              <BrainCircuit size={18} className="text-white" />
            </div>
            <h3 className="text-lg font-semibold text-white">Gemini AI Insights</h3>
          </div>

          {loadingInsights ? (
            <div className="space-y-4 animate-pulse">
              <div className="h-4 bg-slate-800 rounded w-3/4"></div>
              <div className="h-4 bg-slate-800 rounded w-1/2"></div>
              <div className="space-y-2 mt-6">
                <div className="h-8 bg-slate-800 rounded"></div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-slate-300 text-sm leading-relaxed">{insights?.summary}</p>
              <div className="bg-indigo-900/40 p-3 rounded-xl border border-indigo-400/20">
                <span className="text-xs font-bold uppercase text-indigo-300 tracking-wider">Prediction</span>
                <p className="text-indigo-100 text-sm font-medium mt-1">{insights?.predictedCongestion}</p>
              </div>
              <div className="space-y-2 mt-4">
                <h4 className="text-xs font-bold uppercase text-slate-500 tracking-wider">Recommendations</h4>
                {insights?.recommendations.map((rec, i) => (
                  <div key={i} className="flex gap-2 text-sm text-indigo-200">
                    <span className="text-indigo-500 font-bold">•</span>
                    {rec}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold text-white">Recent ANPR Activity</h3>
          <button className="text-blue-400 text-sm hover:underline flex items-center gap-1">
            Logs <ChevronRight size={16} />
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {events.map(event => (
            <div key={event.id} className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden hover:border-blue-500/50 transition-all">
              <div className="relative h-24">
                <img src={event.imageUrl} alt="Vehicle" className="w-full h-full object-cover grayscale opacity-60" />
                <div className="absolute top-2 right-2 bg-blue-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                  Lane {event.lane}
                </div>
              </div>
              <div className="p-3">
                <div className="mono text-blue-400 font-bold tracking-widest text-lg mb-1">{event.plateNumber}</div>
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span>{event.vehicleType}</span>
                  <span>{Math.round(event.confidence * 100)}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ 
  title: string; 
  value: string; 
  change?: string; 
  icon: React.ReactNode;
  status?: 'success' | 'warning' | 'error';
}> = ({ title, value, change, icon, status }) => {
  const statusColors = {
    success: 'text-emerald-400',
    warning: 'text-amber-400',
    error: 'text-rose-400'
  };
  return (
    <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl hover:border-slate-700 transition-colors shadow-sm">
      <div className="flex justify-between items-start mb-4">
        <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">{icon}</div>
      </div>
      <div>
        <h4 className="text-slate-400 text-sm font-medium">{title}</h4>
        <div className={`text-2xl font-bold mt-1 ${status ? statusColors[status] : 'text-white'}`}>{value}</div>
        {change && <p className="text-slate-500 text-xs mt-2 font-medium">{change}</p>}
      </div>
    </div>
  );
};

export default TrafficDashboard;
