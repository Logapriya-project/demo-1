
import React from 'react';
import { TrafficStats, VehicleType } from '../types.ts';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

interface Props {
  stats: TrafficStats;
}

const COLORS = ['#3b82f6', '#f59e0b', '#ef4444', '#10b981', '#6366f1'];

const Analytics: React.FC<Props> = ({ stats }) => {
  const classificationData = Object.entries(stats.vehicleBreakdown)
    .filter(([_, value]) => value > 0)
    .map(([key, value]) => ({ name: key, value }));

  const hourlyFlow = [
    { hour: '00:00', car: 120, truck: 20, bike: 15 },
    { hour: '04:00', car: 80, truck: 45, bike: 10 },
    { hour: '08:00', car: 850, truck: 110, bike: 220 },
    { hour: '12:00', car: 600, truck: 80, bike: 150 },
    { hour: '16:00', car: 900, truck: 130, bike: 310 },
    { hour: '20:00', car: 520, truck: 60, bike: 90 },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="bg-slate-900 border border-slate-800 p-8 rounded-2xl shadow-sm">
        <h3 className="text-xl font-bold text-white mb-2">Vehicle Classification (ATCC)</h3>
        <p className="text-slate-400 text-sm mb-8">Distribution by vehicle category across all lanes</p>
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={classificationData}
                cx="50%"
                cy="50%"
                innerRadius={80}
                outerRadius={120}
                paddingAngle={5}
                dataKey="value"
                stroke="none"
              >
                {classificationData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }}
                itemStyle={{ color: '#fff' }}
              />
              <Legend verticalAlign="bottom" height={36} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 p-8 rounded-2xl shadow-sm">
        <h3 className="text-xl font-bold text-white mb-2">Hourly Throughput</h3>
        <p className="text-slate-400 text-sm mb-8">Classification breakdown by time</p>
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={hourlyFlow}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
              <XAxis dataKey="hour" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip 
                cursor={{ fill: '#1e293b', opacity: 0.5 }}
                contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }}
              />
              <Legend verticalAlign="bottom" height={36} />
              <Bar dataKey="car" name="Cars" fill="#3b82f6" radius={[4, 4, 0, 0]} stackId="a" />
              <Bar dataKey="truck" name="Trucks" fill="#f59e0b" radius={[4, 4, 0, 0]} stackId="a" />
              <Bar dataKey="bike" name="Bikes" fill="#10b981" radius={[4, 4, 0, 0]} stackId="a" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-8 rounded-2xl shadow-sm">
        <h3 className="text-xl font-bold text-white mb-6">Speed Compliance Map</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
            <span className="text-xs font-bold text-slate-500 uppercase">Avg Speed</span>
            <div className="text-3xl font-bold text-emerald-400 mt-1">42 <span className="text-lg font-normal">km/h</span></div>
          </div>
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
            <span className="text-xs font-bold text-slate-500 uppercase">Max Speed</span>
            <div className="text-3xl font-bold text-rose-400 mt-1">118 <span className="text-lg font-normal">km/h</span></div>
          </div>
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
            <span className="text-xs font-bold text-slate-500 uppercase">Violations</span>
            <div className="text-3xl font-bold text-amber-400 mt-1">14 <span className="text-lg font-normal">today</span></div>
          </div>
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
            <span className="text-xs font-bold text-slate-500 uppercase">Optimal</span>
            <div className="text-3xl font-bold text-blue-400 mt-1">45 <span className="text-lg font-normal">km/h</span></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
