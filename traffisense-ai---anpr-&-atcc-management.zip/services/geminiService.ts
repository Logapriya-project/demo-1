
import { GoogleGenAI, Type } from "@google/genai";
import { TrafficStats, TrafficInsight } from "../types.ts";

export const getTrafficInsights = async (stats: TrafficStats): Promise<TrafficInsight> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    return {
      summary: "AI services are initializing. Monitoring standard traffic flow patterns.",
      recommendations: ["Ensure signal sensors are active", "Observe junction B-12 for bottlenecks"],
      predictedCongestion: "Steady flow anticipated"
    };
  }

  const ai = new GoogleGenAI({ apiKey });
  const prompt = `
    As a Senior Smart City Traffic Engineer, analyze the following real-time traffic data:
    - Total Vehicles: ${stats.totalVehicles}
    - Average Speed: ${stats.averageSpeed} km/h
    - Congestion Level: ${stats.congestionLevel}
    - Vehicle Breakdown: ${JSON.stringify(stats.vehicleBreakdown)}

    Provide a concise summary of current conditions, 3 actionable recommendations for traffic signal optimization or routing, and a short prediction for the next hour.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            predictedCongestion: { type: Type.STRING }
          },
          required: ["summary", "recommendations", "predictedCongestion"]
        }
      }
    });

    const text = response.text || "{}";
    return JSON.parse(text);
  } catch (error) {
    console.error("Error fetching Gemini insights:", error);
    return {
      summary: "System processing active. Analyzing throughput patterns.",
      recommendations: ["Ensure priority for emergency lanes", "Monitor junction B12", "Update dynamic message signs"],
      predictedCongestion: "Steady flow expected"
    };
  }
};
