
import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Camera, 
  BarChart3, 
  List, 
  Settings, 
  ShieldAlert, 
  TrendingUp, 
  Cpu,
  Clock,
  Car
} from 'lucide-react';
import TrafficDashboard from './components/TrafficDashboard.tsx';
import ANPRLog from './components/ANPRLog.tsx';
import Analytics from './components/Analytics.tsx';
import LiveFeed from './components/LiveFeed.tsx';
import { TrafficStats, ANPREvent, VehicleType } from './types.ts';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'anpr' | 'analytics' | 'live'>('dashboard');
  const [stats, setStats] = useState<TrafficStats>({
    totalVehicles: 1248,
    averageSpeed: 42,
    congestionLevel: 'Medium',
    vehicleBreakdown: {
      [VehicleType.CAR]: 840,
      [VehicleType.TRUCK]: 120,
      [VehicleType.BUS]: 45,
      [VehicleType.MOTORCYCLE]: 243,
      [VehicleType.LVC]: 0,
      [VehicleType.HVC]: 0
    }
  });

  const [anprEvents, setAnprEvents] = useState<ANPREvent[]>([]);

  // Simulation: Add random ANPR events
  useEffect(() => {
    const interval = setInterval(() => {
      const plates = ['ABC-1234', 'XYZ-9876', 'MH12-DE45', 'DL8-CA1234', 'KA01-PQ999'];
      const types = [VehicleType.CAR, VehicleType.TRUCK, VehicleType.MOTORCYCLE, VehicleType.BUS];
      
      const newEvent: ANPREvent = {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date(),
        plateNumber: plates[Math.floor(Math.random() * plates.length)],
        vehicleType: types[Math.floor(Math.random() * types.length)],
        confidence: Number((0.85 + Math.random() * 0.14).toFixed(2)),
        lane: Math.floor(Math.random() * 4) + 1,
        imageUrl: `https://picsum.photos/seed/${Math.random()}/200/100`
      };

      setAnprEvents(prev => [newEvent, ...prev].slice(0, 50));
      
      setStats(prev => ({
        ...prev,
        totalVehicles: prev.totalVehicles + 1,
        vehicleBreakdown: {
          ...prev.vehicleBreakdown,
          [newEvent.vehicleType]: prev.vehicleBreakdown[newEvent.vehicleType] + 1
        }
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex h-screen w-full overflow-hidden bg-slate-950">
      {/* Sidebar */}
      <nav className="w-20 md:w-64 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0">
        <div className="p-6 flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg">
            <Activity className="text-white w-6 h-6" />
          </div>
          <h1 className="hidden md:block font-bold text-xl tracking-tight text-white">TraffiSense AI</h1>
        </div>

        <div className="flex-1 px-4 py-6 space-y-2">
          <SidebarItem 
            icon={<BarChart3 size={20} />} 
            label="Dashboard" 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
          />
          <SidebarItem 
            icon={<Camera size={20} />} 
            label="Live Monitoring" 
            active={activeTab === 'live'} 
            onClick={() => setActiveTab('live')} 
          />
          <SidebarItem 
            icon={<List size={20} />} 
            label="ANPR Logs" 
            active={activeTab === 'anpr'} 
            onClick={() => setActiveTab('anpr')} 
          />
          <SidebarItem 
            icon={<TrendingUp size={20} />} 
            label="ATCC Analytics" 
            active={activeTab === 'analytics'} 
            onClick={() => setActiveTab('analytics')} 
          />
        </div>

        <div className="p-4 border-t border-slate-800">
          <SidebarItem icon={<Settings size={20} />} label="System Config" active={false} onClick={() => {}} />
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-slate-950 p-6 md:p-8">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-2xl font-bold text-white capitalize">{activeTab.replace('-', ' ')}</h2>
            <p className="text-slate-400 text-sm">Real-time Smart Traffic Management System</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-full border border-slate-800">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-xs font-medium text-slate-300">Live Server Connected</span>
            </div>
            <button className="bg-slate-900 p-2 rounded-full border border-slate-800 text-slate-400 hover:text-white transition-colors">
              <ShieldAlert size={20} />
            </button>
          </div>
        </header>

        <div className="max-w-7xl mx-auto">
          {activeTab === 'dashboard' && <TrafficDashboard stats={stats} events={anprEvents.slice(0, 5)} />}
          {activeTab === 'anpr' && <ANPRLog events={anprEvents} />}
          {activeTab === 'analytics' && <Analytics stats={stats} />}
          {activeTab === 'live' && <LiveFeed />}
        </div>
      </main>
    </div>
  );
};

const SidebarItem: React.FC<{ icon: React.ReactNode, label: string, active: boolean, onClick: () => void }> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-4 px-3 py-3 rounded-xl transition-all ${
      active ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
    }`}
  >
    {icon}
    <span className="hidden md:block font-medium text-sm">{label}</span>
  </button>
);

export default App;
