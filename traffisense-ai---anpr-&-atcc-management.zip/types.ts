
export enum VehicleType {
  CAR = 'Car',
  TRUCK = 'Truck',
  BUS = 'Bus',
  MOTORCYCLE = 'Motorcycle',
  LVC = 'Light Vehicle',
  HVC = 'Heavy Vehicle'
}

export interface ANPREvent {
  id: string;
  timestamp: Date;
  plateNumber: string;
  vehicleType: VehicleType;
  confidence: number;
  lane: number;
  imageUrl: string;
}

export interface TrafficStats {
  totalVehicles: number;
  averageSpeed: number;
  congestionLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  vehicleBreakdown: {
    [key in VehicleType]: number;
  };
}

export interface TrafficInsight {
  summary: string;
  recommendations: string[];
  predictedCongestion: string;
}
